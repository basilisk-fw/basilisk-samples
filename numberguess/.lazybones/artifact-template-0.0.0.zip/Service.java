package ${project_package};

import basilisk.core.artifact.BasiliskService;
import basilisk.metadata.ArtifactProviderFor;
import org.kordamp.basilisk.runtime.core.artifact.AbstractBasiliskService;

@ArtifactProviderFor(BasiliskService.class)
public class ${project_class_name}Service extends AbstractBasiliskService {

}